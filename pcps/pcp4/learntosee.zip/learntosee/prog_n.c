int sumN(int n){
  int result = 0;
  for(int i = 0; i < n; i++){
    result += i;
  }
  return result;
}


int main(void){
  int n = 10;
  return sumN(10);
}
