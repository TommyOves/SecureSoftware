int mod13(int n){
  int result = 0;
  result = n % 13;
  return result;
}


int main(void){
  return mod13(7);
}
