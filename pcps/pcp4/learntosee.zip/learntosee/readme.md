# See the C in the sea of assembly

elf0 was compiled from prog_n.c 
the flag starts with 'n'
elf1 was compiled from prog_??.c and the 
2nd character of the flag is ??
etc.

1) for loops
2) if statements
3) arithmetic
4) variable assignments
5) declare a function
6) call your function
7) declare an array of some type
8) structs
9) malloc to ask for memory
10) pointers and dereferencing for access
11) basic string (char array) manipulation
12) do some file input/output
13) use some formated printf statements
