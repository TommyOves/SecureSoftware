#include <stdlib.h>
#include <stdio.h>

int func(int n, int y){
   printf("%d\n",n);
   return 0;
}


int main(void){
  return func(72, 32);
}
