#include <stdlib.h>
#include <stdio.h>

int func(int n, int y){
   char x[100];
   fgets(x, 100, stdin);
   return 0;
}


int main(void){
  return func(72, 32);
}
